/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mibiblioteca;

import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class ModeloLibros {

    //ATRIBUTOS PRIVADOS
    private Libro[] lista; //Array con los libros que contiene el modelo.
    private int elementos; //Número de elementos que contiene el array.

    //ATRIBUTOS PÚBLICOS
    /*Número de elementos máximos que pueden almacenarse. Será de 100.*/
    public static final int MAX_ELEMENTOS = 100;

    //CONSTRUCTORES
    /*Constructor que inicializa el array de elementos con la capacidad por defecto. 
    Hará uso de this().*/
    public ModeloLibros() {
        this(MAX_ELEMENTOS);
    }

    /*Constructor que inicializa el array de elementos con la capacidad indicada por parámetro.*/
    public ModeloLibros(int elementos) {
        elementos = 0;
        lista = new Libro[elementos];
    }

    //MÉTODOS PÚBLICOS
    /*Devuelve el número de libros que hay almacenados.*/
    public int getElementos() {
        return elementos;
    }

    /*Añade un libro a la lista y devuelve true si se añadió correctamente.
    Devuelve false si no pudo añadirse por no haber más espacio.*/
    public boolean añadir(Libro l) {
        //Primero se comprueba que haya espacio de almacenamiento
        if (elementos == lista.length) {
            return false;
        }
        //si hay espacio, guardamos el libro en la posición libre
        this.lista[elementos] = l;
        elementos++;
        return true;

    }

    /*Se elimina el libro de la lista. Tras la eliminación debe compactar la lista de elementos.*/
    public boolean eliminar(String isbn) {
        //Si no lo está, pasamos a la eliminación
        Libro l = buscar(isbn);
        if (l != null) {
            l = null;
            elementos--;
            return true;
        }
        return false;
    }

    /*Devuelve el objeto libro que coincide con el isbn indicado por parámetro. 
    Si la búsqueda no tiene éxito devuelve null.*/
    public Libro buscar(String isbn) {
        for (Libro l : lista) {
            if (l.getISBN().equals(isbn)) {
                return l;
            }
        }
        return null;
    }

    /*Devuelve un array de libros cuyo título contiene la cadena de búsqueda indicada por parámetro. 
    Si la búsqueda no tiene éxito devuelve null.*/
    public Libro[] buscarTitulo(String titulo) {
        ArrayList<Libro> iguales = new ArrayList<>();
        for (int i = 0; i < lista.length; i++) {
            if (lista[i].getTitulo().contains(titulo)) {
                iguales.add(lista[i]);
            }
        }
        if (iguales.isEmpty()) {
            return null;
        } else {
            Libro[] mismo = new Libro[iguales.size()];
            mismo = iguales.toArray(mismo);
            return mismo;
        }
    }

    /*Devuelve un array de libros cuyo autor coincide con el parámetro buscado. 
    Si la búsqueda no tiene éxito devuelve null.*/
    public Libro[] buscarAutor(String titulo) {
        ArrayList<Libro> iguales = new ArrayList<>();
        for (int i = 0; i < lista.length; i++) {
            if (lista[i].getTitulo().contains(titulo)) {
                iguales.add(lista[i]);
            }
        }
        if (iguales.isEmpty()) {
            return null;
        } else {
            Libro[] mismo = new Libro[iguales.size()];
            mismo = iguales.toArray(mismo);
            return mismo;
        }

    }
}
