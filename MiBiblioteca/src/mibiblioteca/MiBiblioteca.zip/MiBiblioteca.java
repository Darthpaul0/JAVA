/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mibiblioteca;


import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Pablo
 */
public class MiBiblioteca {

    //ATRIBUTOS PRIVADOS
    private static ModeloLibros biblioteca;
    private static ArrayList<Prestamo> prestamos;

    public static void main(String[] args) {
        int opcion;
        do {
            opcion = generarMenuPrincipal();
            System.out.println("Ha elegido la opción: " + opcion);
            switch (opcion) {

                case 1:/*Añadir nuevo libro. */

                    break;

                case 2:/*Eliminar un libro. */
                    break;

                case 3://Buscar libro. Mostrará al usuario el siguiente submenú de opciones.
                    int opcionbusqueda;
                    do {
                        opcionbusqueda = generarMenuBusqueda();
                        switch (opcionbusqueda) {

                            case 1:/*Buscar libro por título.*/
                                break;

                            case 2:/*Buscar libro por autor.*/
                                break;

                            case 3:/*Buscar libro por ISBN.*/
                                break;

                            case 4://Vuelve al menú principal.
                                break;
                        }
                    } while (opcionbusqueda != 4);
                    break;

                case 4:/*Prestar libros.*/
                    break;

                case 5:/*Devolver libros.*/
                    break;

                case 6:/*Prorrogar préstamo.*/
                    break;

                case 7:/*Consultar préstamos.*/
                    int opcionprestamo;
                    do {
                        opcionprestamo = generarMenuConsulta();
                        switch (opcionprestamo) {

                            case 1://Consultar todos los préstamos.
                                break;
                            case 2://Consultar préstamos caducados
                                break;
                            case 3:// Consultar préstamos próximos a caducar
                                break;
                            case 4:// Volver al menú principal
                                break;
                        }
                    } while (opcionprestamo != 4);
                    break;

                case 8://Salir del programa
                    break;
            }
        } while (opcion != 8);
    }

    public static int generarMenuPrincipal() {
        // Estructura del menú

        int opcion = 0;
        Scanner teclado = new Scanner(System.in);

        do {
            System.out.println("--Menú principal de la bibliteca--");
            System.out.println("¿Qué operación quiere realizar hoy?");
            System.out.println("------");
            System.out.println("1. Añadir nuevo libro");
            System.out.println("2. Eliminar un libro.");
            System.out.println("3. Buscar un libro.");
            System.out.println("4. Prestar libros.");
            System.out.println("5. Devolver libros.");
            System.out.println("6. Prorrogar préstamo.");
            System.out.println("7. Consultar préstamos.");
            System.out.println("8. Salir del programa.");
            System.out.println("------");

            while (!teclado.hasNextInt()) {
                teclado.next(); //si lo que se ha introducido no es un número lo sacamos del buffer
                System.out.println("El valor introducido no es un número, vuelva a intentarlo:");
            }
            opcion = teclado.nextInt();

        } while (opcion < 1 || opcion > 9);

        return opcion;
    }

    public static int generarMenuBusqueda() {
        // Estructura del menú

        int opcion = 0;
        Scanner teclado = new Scanner(System.in);

        do {
            System.out.println("--Menú de búsquedas--");
            System.out.println("¿Qué operación quiere realizar?");
            System.out.println("------");
            System.out.println("1. Buscar libro por título.");
            System.out.println("2. Buscar libro por autor.");
            System.out.println("3. Buscar libro por ISBN.");
            System.out.println("4. Volver al menú principal.");
            System.out.println("------");

            while (!teclado.hasNextInt()) {
                teclado.next(); //si lo que se ha introducido no es un número lo sacamos del buffer
                System.out.println("El valor introducido no es un número, vuelva a intentarlo:");
            }
            opcion = teclado.nextInt();

        } while (opcion < 1 || opcion > 5);

        return opcion;
    }

    public static int generarMenuConsulta() {
        // Estructura del menú

        int opcion = 0;
        Scanner teclado = new Scanner(System.in);

        do {
            System.out.println("--Menú de consultas--");
            System.out.println("¿Qué operación quiere realizar?");
            System.out.println("------");
            System.out.println("1. Consultar todos los préstamos.");
            System.out.println("2. Consultar préstamos caducados..");
            System.out.println("3. Consultar préstamos con fecha de vencimiento cercana.");
            System.out.println("4. Volver al menú principal.");
            System.out.println("------");

            while (!teclado.hasNextInt()) {
                teclado.next(); //si lo que se ha introducido no es un número lo sacamos del buffer
                System.out.println("El valor introducido no es un número, vuelva a intentarlo:");
            }
            opcion = teclado.nextInt();

        } while (opcion < 1 || opcion > 5);

        return opcion;
    }

}
